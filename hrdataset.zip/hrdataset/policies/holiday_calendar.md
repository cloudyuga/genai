# Holiday Calendar

| Festival Name          | Date       | Day         |
|------------------------|------------|-------------|
| Republic Day          | 2023-01-26 | Thursday    |
| Holi                 | 2023-03-08 | Wednesday   |
| Good Friday          | 2023-04-07 | Friday      |
| Eid al-Fitr          | 2023-04-22 | Saturday    |
| Independence Day     | 2023-08-15 | Tuesday     |
| Raksha Bandhan       | 2023-08-30 | Wednesday   |
| Ganesh Chaturthi     | 2023-09-19 | Tuesday     |
| Diwali               | 2023-11-12 | Sunday      |
| Christmas            | 2023-12-25 | Monday      |
| Makar Sankranti      | 2023-01-14 | Saturday    |
