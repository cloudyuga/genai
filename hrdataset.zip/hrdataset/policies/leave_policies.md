# Leave Policies
- **Annual Leave:** 18 days of paid leave per year, accrued monthly.
- **Sick Leave:** 12 days of paid leave for medical reasons per year.
- **Maternity Leave:** 6 months of paid leave for expecting mothers.
- **Paternity Leave:** 15 days of paid leave for new fathers.L
- **Compensatory Leave:** Leave granted for working on weekends or holidays.
