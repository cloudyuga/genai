# Events and Holiday Calendar

| Event Name            | Date       | Time     | Location        | Participants           |
|-----------------------|------------|----------|-----------------|------------------------|
| Annual Company Meet   | 2023-12-15 | 10:00 AM | Mumbai Office   | All employees          |
| Health Camp           | 2023-11-10 | 09:00 AM | Bangalore Office| All employees          |
| Team Building Event   | 2023-09-05 | 02:00 PM | Goa Resort      | Operations Team        |
