# Employee Benefits
- **Health Insurance:** Covers employee and dependents up to ₹5,00,000.
- **Provident Fund:** 12% of basic salary contributed to the PF account.
- **Gratuity:** Paid on retirement/resignation based on tenure.
- **Travel Allowance:** Reimbursement for official travel expenses.
- **Skill Development:** Reimbursement for approved certifications/training costs.
