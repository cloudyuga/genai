# Training and Development

| Employee ID | Name           | Courses Taken                          | Completion Date | Certifications Awarded      |
|-------------|----------------|----------------------------------------|-----------------|----------------------------|
| 101         | Priya Sharma   | Leadership in Operations              | 2022-12-10      | Certified Operations Manager |
| 102         | Rohit Mehra    | Data Analytics for Logistics          | 2021-11-15      | Certified Logistics Analyst |
| 103         | Anjali Das     | HR Management Essentials              | 2023-03-05      | Certified HR Professional   |
