# Employee Profile: Aditya Jain

## Basic Information
- **Employee ID:** 110
- **Name:** Aditya Jain
- **Role:** Senior Developer
- **Department:** IT
- **Manager:** Rajesh Kulkarni
- **Contact:** +91-9876765432
- **Joining Date:** 2019-06-10
- **Date of Birth:** 1989-03-05
- **Hobbies:** Coding, Chess

## Performance Ratings
- **2019:** 4.6
- **2020:** 4.7
- **2021:** 4.8
- **2022:** 4.8

## Onboarding Status
- N/A
