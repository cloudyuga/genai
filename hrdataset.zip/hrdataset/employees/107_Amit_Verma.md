# Employee Profile: Amit Verma

## Basic Information
- **Employee ID:** 107
- **Name:** Amit Verma
- **Role:** CEO
- **Department:** Executive
- **Manager:** -
- **Contact:** +91-1234567890
- **Joining Date:** 2016-02-01
- **Date of Birth:** 1975-06-15
- **Hobbies:** Golf, Reading

## Performance Ratings
- **2019:** 5.0
- **2020:** 5.0
- **2021:** 5.0
- **2022:** 5.0

## Onboarding Status
- N/A
