# Employee Profile: Rohit Mehra

## Basic Information
- **Employee ID:** 102
- **Name:** Rohit Mehra
- **Role:** Logistics Analyst
- **Department:** Logistics
- **Manager:** Priya Sharma
- **Contact:** +91-8765432109
- **Joining Date:** 2020-08-22
- **Date of Birth:** 1992-07-19
- **Hobbies:** Chess, Photography

## Performance Ratings
- **2020:** 4.5
- **2021:** 4.6
- **2022:** 4.8
- **2023:** 4.7

## Onboarding Status
- N/A
