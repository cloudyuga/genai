# Employee Profile: Karan Kapoor

## Basic Information
- **Employee ID:** 104
- **Name:** Karan Kapoor
- **Role:** Fleet Supervisor
- **Department:** Logistics
- **Manager:** Priya Sharma
- **Contact:** +91-8877665544
- **Joining Date:** 2018-11-03
- **Date of Birth:** 1985-09-25
- **Hobbies:** Cricket, Hiking

## Performance Ratings
- **2019:** 4.6
- **2020:** 4.7
- **2021:** 4.8
- **2022:** 4.9

## Onboarding Status
- N/A
