# Payroll Information

| Employee ID | Name           | Salary (INR) | HRA   | Provident Fund | Tax Slab   | Payday                 |
|-------------|----------------|--------------|-------|----------------|------------|-----------------------|
| 101         | Priya Sharma   | 12,00,000    | 40%   | 12%            | 30%        | Last working day of month |
| 102         | Rohit Mehra    | 8,50,000     | 35%   | 12%            | 20%        | Last working day of month |
