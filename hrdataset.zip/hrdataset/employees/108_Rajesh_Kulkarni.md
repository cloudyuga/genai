# Employee Profile: Rajesh Kulkarni

## Basic Information
- **Employee ID:** 108
- **Name:** Rajesh Kulkarni
- **Role:** CTO
- **Department:** Executive
- **Manager:** Amit Verma
- **Contact:** +91-9087654321
- **Joining Date:** 2017-11-15
- **Date of Birth:** 1980-08-20
- **Hobbies:** Traveling, Painting

## Performance Ratings
- **2019:** 4.9
- **2020:** 4.8
- **2021:** 5.0
- **2022:** 4.9

## Onboarding Status
- N/A
