# Employee Profile: Sunita Patil

## Basic Information
- **Employee ID:** 105
- **Name:** Sunita Patil
- **Role:** Finance Executive
- **Department:** Finance
- **Manager:** Rajesh Kulkarni
- **Contact:** +91-7766554433
- **Joining Date:** 2022-01-17
- **Date of Birth:** 1993-11-11
- **Hobbies:** Painting, Running

## Performance Ratings

## Onboarding Status
- Document Submission Pending
