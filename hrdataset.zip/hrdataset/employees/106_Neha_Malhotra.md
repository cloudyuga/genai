# Employee Profile: Neha Malhotra

## Basic Information
- **Employee ID:** 106
- **Name:** Neha Malhotra
- **Role:** Junior Analyst
- **Department:** Logistics
- **Manager:** Priya Sharma
- **Contact:** +91-6655443322
- **Joining Date:** 2023-07-01
- **Date of Birth:** 1998-03-21
- **Hobbies:** Singing, Blogging

## Performance Ratings

## Onboarding Status
- Orientation Completed
