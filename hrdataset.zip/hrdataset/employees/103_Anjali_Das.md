# Employee Profile: Anjali Das

## Basic Information
- **Employee ID:** 103
- **Name:** Anjali Das
- **Role:** HR Executive
- **Department:** Human Resources
- **Manager:** Ramesh Nair
- **Contact:** +91-9988776655
- **Joining Date:** 2021-05-10
- **Date of Birth:** 1995-01-15
- **Hobbies:** Cooking, Gardening

## Performance Ratings
- **2021:** 4.2
- **2022:** 4.3
- **2023:** 4.5

## Onboarding Status
- N/A
