# Employee Profile: Meera Iyer

## Basic Information
- **Employee ID:** 109
- **Name:** Meera Iyer
- **Role:** Marketing Manager
- **Department:** Marketing
- **Manager:** Amit Verma
- **Contact:** +91-9988998877
- **Joining Date:** 2020-02-20
- **Date of Birth:** 1990-12-10
- **Hobbies:** Writing, Yoga

## Performance Ratings
- **2020:** 4.7
- **2021:** 4.8
- **2022:** 4.9
- **2023:** 4.9

## Onboarding Status
- N/A
