# Employee Profile: Priya Sharma

## Basic Information
- **Employee ID:** 101
- **Name:** Priya Sharma
- **Role:** Operations Manager
- **Department:** Operations
- **Manager:** Amit Verma
- **Contact:** +91-9876543210
- **Joining Date:** 2019-03-15
- **Date of Birth:** 1988-04-12
- **Hobbies:** Reading, Traveling

## Performance Ratings
- **2019:** 4.8
- **2020:** 4.7
- **2021:** 4.9
- **2022:** 5.0

## Onboarding Status
- N/A
